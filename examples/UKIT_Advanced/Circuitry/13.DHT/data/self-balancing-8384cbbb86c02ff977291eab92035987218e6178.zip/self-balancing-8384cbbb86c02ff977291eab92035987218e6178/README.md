# self-balancing
Nama Kelompok : Edgar Christian (00000030573), Axel Patria, Arsheldy Alvin (00000028323), Julando Omar, Christian Kaunang
Project UAS Pemodelan dan Simulasi - Self Balancing Robot
